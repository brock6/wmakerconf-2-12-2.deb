use     LWP::Simple;
require LWP::Protocol::file;

# get new tile

$rc = getstore ($url, $tmpfile);

# check error conditions

quit ("HTTP response: " . status_message($rc) . ".") unless is_success ($rc);
