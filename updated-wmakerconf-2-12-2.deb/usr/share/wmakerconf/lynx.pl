quit ("Lynx not installed") if $wwwget eq "";

$rc = system ("$wwwget -source '$url' >$tmpfile");

quit ("HTTP response error.") if $rc;
