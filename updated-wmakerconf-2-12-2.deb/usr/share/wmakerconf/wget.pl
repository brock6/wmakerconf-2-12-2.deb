quit ("Wget not installed") if $wwwget eq "";

$rc = system ("$wwwget --quiet -c --tries=0 -O$tmpfile '$url'");

quit ("HTTP response error.") if $rc;
